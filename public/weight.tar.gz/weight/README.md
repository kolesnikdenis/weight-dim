# weight-dim
